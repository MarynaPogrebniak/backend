package de.ait.todolist.dto;

import de.ait.todolist.validation.constraints.BeforeCurrentDate;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.*;

@Data
@Schema(description = "Добавляемая задача")
public class NewTaskDto {

    @NotNull
    @NotBlank
    @Schema(description = "Название задачи", example = "Название задачи...")
    private String title;

    @NotNull
    @NotBlank
    @Schema(description = "Текст задачи", example = "Текст задачи...")
    private String description;

    @BeforeCurrentDate
    @NotNull
    @NotBlank
    @Schema(description = "Дата начала задачи в формате YYYY-MM-DD", example = "2022-02-02")
    private String startDate;

    @Schema(description = "Дата окончания задачи в формате YYYY-MM-DD", example = "2022-09-02")
    private String finishDate;
}