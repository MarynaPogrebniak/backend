package de.ait.todolist.validation.validators;

import de.ait.todolist.validation.constraints.BeforeCurrentDate;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.annotation.Annotation;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class BeforeCurrentDateValidator implements ConstraintValidator<BeforeCurrentDate, String> {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    @Override
    public boolean isValid(String startDate, ConstraintValidatorContext constraintValidatorContext) {

        LocalDate startDateLD = LocalDate.parse(startDate, formatter);
        LocalDate currentDate = LocalDate.now();

        return startDateLD.isEqual(currentDate) || startDateLD.isAfter(currentDate);
    }
}
