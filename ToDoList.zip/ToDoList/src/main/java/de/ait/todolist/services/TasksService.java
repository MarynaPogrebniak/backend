package de.ait.todolist.services;

import de.ait.todolist.dto.TaskDto;
import de.ait.todolist.dto.NewTaskDto;

public interface TasksService {
    TaskDto addTask(NewTaskDto newTask, Long UserId);
}
